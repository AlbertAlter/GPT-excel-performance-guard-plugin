---
name: excel-performance-guard
description: "Create, edit, or review Excel workbooks while preventing oversized conditional-formatting ranges and other edit-time performance regressions. Use for .xlsx work that adds, copies, repairs, or audits conditional formatting, especially duplicate-value highlighting."
---

# Excel Performance Guard

Keep Excel workbooks responsive during ordinary cell edits. Apply these rules alongside the normal spreadsheet workflow; the user's explicit requirements and supplied template remain authoritative.

## Conditional formatting

- Bound every new conditional-formatting rule to the actual data region. Never use entire-column or entire-row ranges such as `A:A`, `1:1`, `A1:A1048576`, or their fragmented equivalents unless the user explicitly requires that exact scope.
- For duplicate-value highlighting, use the smallest relevant record range and exclude headers. For example, prefer `A2:A903` over `A:A`.
- Do not preallocate rules to Excel's last row. If modest growth capacity is useful, use a clearly limited buffer proportional to the current table, or use a native Excel Table so formatting expands with records.
- Consolidate identical rules that have the same format and logic. Avoid overlapping or fragmented `sqref` ranges created by repeated copying, inserting, or per-cell operations.
- Preserve intentional distinctions between columns or sections; do not combine rules merely to reduce their count when that changes the meaning.

## Existing workbooks

- Before adding or copying conditional formatting, inspect the existing rules and their `Applies to` ranges.
- Treat ranges extending far beyond the used data region, repeated duplicate-value rules, and highly fragmented ranges as performance risks.
- When the user asked for a narrow edit, do not silently redesign unrelated formatting. Report pre-existing risks unless repairing them is within scope.
- When repairing performance, work on a copy unless the user explicitly authorizes overwriting the original. Preserve values, formulas, sheet order, styles, and intended highlighting behavior.

## Verification before delivery

- Compare every affected rule's applied range with the sheet's used rows and columns.
- Confirm that no affected rule reaches row `1048576` or column `XFD` unless explicitly requested.
- Check that duplicate-value formatting is not duplicated or stacked over the same cells.
- Recalculate and reopen the exported workbook when the available tools support it. Test a representative cell edit when practical. If native Excel responsiveness could not be tested, state that limitation.
- Report the final bounded ranges and any remaining performance risks succinctly.
